#!/bin/bash

set -euo pipefail

echo "Input file: $input_file"

echo "Running code" > OUTPUT.txt

echo "DONE"